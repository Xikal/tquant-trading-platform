from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
import math
from collections import defaultdict
from typing import Any

from app.services.low_buy.shared import PERFORMANCE_FORWARD_DAYS
from app.services.low_buy.execution_simulation import ROUND_TRIP_COST_BPS
from app.services.low_buy.strategy_families import resolve_strategy_family_label

try:
    from .low_buy_market_backtest_signal_stats import (
        CONFIRMED_STATES,
        EVALUATED_STATES,
        NEAR_ENTRY_STATE,
        OBSERVE_CONFIRMED_STATE,
        conclusion_source,
        pct,
        profit_factor,
        signal_group_stats,
    )
except ImportError:
    from low_buy_market_backtest_signal_stats import (
        CONFIRMED_STATES,
        EVALUATED_STATES,
        NEAR_ENTRY_STATE,
        OBSERVE_CONFIRMED_STATE,
        conclusion_source,
        pct,
        profit_factor,
        signal_group_stats,
    )


@dataclass
class TradeOutcome:
    symbol: str
    name: str
    signal_date: str
    strategy_key: str
    buy_signal_state: str
    entry_price: float
    execution_status: str
    net_return_pct: float
    execution_exit_reason: str
    return_1d: float
    return_2d: float
    return_3d: float
    return_4d: float
    return_5d: float
    max_gain_5d: float
    max_drawdown_5d: float
    entry_zone_low: float = 0.0
    entry_zone_high: float = 0.0
    spike_return_1d: float = 0.0
    spike_return_2d: float = 0.0
    spike_return_3d: float = 0.0
    spike_return_4d: float = 0.0
    spike_return_5d: float = 0.0
    t1_high_return_pct: float = 0.0
    t1_close_return_pct: float = 0.0
    t1_spike_fade_pct: float = 0.0
    t2_high_return_pct: float = 0.0
    t2_close_return_pct: float = 0.0
    t1_hit_3_pct: bool = False
    t1_hit_5_pct: bool = False
    t1_fade_to_entry: bool = False
    entry_trade_date: str = ""
    exit_trade_date: str = ""
    market_state: str = ""
    market_state_text: str = ""
    market_state_category: str = ""
    market_state_strength: float = 0.0
    sector_name: str = ""
    production_score: float | None = None
    watch_score: float | None = None
    production_decision: str = ""
    front_row_tier: str = "unknown"
    score_cap: float | None = None
    score_components: dict[str, float] = field(default_factory=dict)
    exclusion_reasons: list[str] = field(default_factory=list)
    warning_tags: list[str] = field(default_factory=list)
    production_scoring_config_version: str = ""
    signal_generated_at: str = ""
    data_cutoff_time: str = ""
    return_start_time: str = ""
    t1_open_return_pct: float = 0.0
    t1_pct_chg: float = 0.0
    t1_locked_limit_up: bool = False


@dataclass
class StrategyBacktestStats:
    strategy_key: str
    strategy_title: str
    strategy_family: str
    strategy_family_text: str
    snapshot_count: int = 0
    snapshot_dates: set[str] = field(default_factory=set)
    failed_snapshot_count: int = 0
    scanned_count: int = 0
    matched_count: int = 0
    confirmed_count: int = 0
    observe_confirmed_count: int = 0
    near_entry_count: int = 0
    watch_count: int = 0
    avoid_count: int = 0
    evaluated_count: int = 0
    pending_count: int = 0
    outcomes: list[TradeOutcome] = field(default_factory=list)
    signal_state_counts: dict[str, int] = field(default_factory=dict)
    skipped_by_state_count: int = 0
    skipped_by_state_counts: dict[str, int] = field(default_factory=dict)
    pending_reason_counts: dict[str, int] = field(default_factory=dict)
    market_guard_count: int = 0
    market_guard_counts: dict[str, int] = field(default_factory=dict)
    front_row_filter_count: int = 0
    front_row_filter_counts: dict[str, int] = field(default_factory=dict)

    def record_signal_state(self, state: str) -> None:
        key = str(state or "unknown")
        self.signal_state_counts[key] = self.signal_state_counts.get(key, 0) + 1

    def record_skipped_state(self, state: str) -> None:
        key = str(state or "unknown")
        self.skipped_by_state_count += 1
        self.skipped_by_state_counts[key] = self.skipped_by_state_counts.get(key, 0) + 1

    def record_pending_reason(self, reason: str) -> None:
        key = str(reason or "unknown")
        self.pending_reason_counts[key] = self.pending_reason_counts.get(key, 0) + 1

    def record_market_guard(self, reason: str) -> None:
        key = str(reason or "unknown")
        self.market_guard_count += 1
        self.market_guard_counts[key] = self.market_guard_counts.get(key, 0) + 1

    def record_front_row_filter(self, reason: str, count: int = 1) -> None:
        key = str(reason or "unknown")
        amount = max(int(count or 0), 0)
        self.front_row_filter_count += amount
        self.front_row_filter_counts[key] = self.front_row_filter_counts.get(key, 0) + amount

    def as_dict(self, target_profit_pct: float, selected_states: set[str] | None = None) -> dict[str, Any]:
        confirmed_result = signal_group_stats(
            outcomes=self.outcomes,
            states=CONFIRMED_STATES,
            target_profit_pct=target_profit_pct,
        )
        near_entry_result = signal_group_stats(
            outcomes=self.outcomes,
            states={NEAR_ENTRY_STATE},
            target_profit_pct=target_profit_pct,
        )
        buy_now_result = signal_group_stats(
            outcomes=self.outcomes,
            states={"buy_now"},
            target_profit_pct=target_profit_pct,
        )
        soft_buy_now_result = signal_group_stats(
            outcomes=self.outcomes,
            states={"soft_buy_now"},
            target_profit_pct=target_profit_pct,
        )
        observe_confirmed_result = signal_group_stats(
            outcomes=self.outcomes,
            states={OBSERVE_CONFIRMED_STATE},
            target_profit_pct=target_profit_pct,
        )
        backtest_metrics = backtest_performance_metrics(self.outcomes, states=CONFIRMED_STATES)
        all_evaluated_backtest_metrics = backtest_performance_metrics(self.outcomes, states=EVALUATED_STATES)
        conclusion_result = conclusion_source(confirmed_result, observe_confirmed_result, near_entry_result)
        selected = selected_states or EVALUATED_STATES
        total_result = signal_group_stats(
            outcomes=self.outcomes,
            states=selected,
            target_profit_pct=target_profit_pct,
        )
        return {
            "strategy_key": self.strategy_key,
            "strategy_title": self.strategy_title,
            "strategy_family": self.strategy_family,
            "strategy_family_text": self.strategy_family_text,
            "snapshot_count": self.snapshot_count,
            "snapshot_start": min(self.snapshot_dates) if self.snapshot_dates else "",
            "snapshot_end": max(self.snapshot_dates) if self.snapshot_dates else "",
            "failed_snapshot_count": self.failed_snapshot_count,
            "scanned_count": self.scanned_count,
            "matched_count": self.matched_count,
            "confirmed_count": self.confirmed_count,
            "observe_confirmed_count": self.observe_confirmed_count,
            "near_entry_count": self.near_entry_count,
            "watch_count": self.watch_count,
            "avoid_count": self.avoid_count,
            "evaluated_count": self.evaluated_count,
            "pending_count": self.pending_count,
            "selected_signal_states": sorted(selected),
            "signal_state_counts": _sorted_counts(self.signal_state_counts),
            "evaluation_diagnostics": {
                "selected_signal_states": sorted(selected),
                "skipped_by_state_count": self.skipped_by_state_count,
                "skipped_by_state_counts": _sorted_counts(self.skipped_by_state_counts),
                "pending_reason_counts": _sorted_counts(self.pending_reason_counts),
                "market_guard_count": self.market_guard_count,
                "market_guard_counts": _sorted_counts(self.market_guard_counts),
                "front_row_filter_count": self.front_row_filter_count,
                "front_row_filter_counts": _sorted_counts(self.front_row_filter_counts),
                "not_filled_reason_counts": _reason_counts(
                    self.outcomes,
                    status="not_filled",
                    field="execution_exit_reason",
                ),
                "filled_exit_reason_counts": _reason_counts(
                    self.outcomes,
                    status="filled",
                    field="execution_exit_reason",
                ),
            },
            "confirmed_result": confirmed_result,
            "buy_now_result": buy_now_result,
            "soft_buy_now_result": soft_buy_now_result,
            "observe_confirmed_result": observe_confirmed_result,
            "near_entry_result": near_entry_result,
            "total_evaluated_result": total_result,
            "backtest_metrics": backtest_metrics,
            "production_backtest_metrics": backtest_metrics,
            "all_evaluated_backtest_metrics": all_evaluated_backtest_metrics,
            "hit_count": confirmed_result["hit_count"],
            "hit_rate": confirmed_result["hit_rate"],
            "win_rate_1d": confirmed_result["win_rate_1d"],
            "win_rate_2d": confirmed_result["win_rate_2d"],
            "win_rate_3d": confirmed_result["win_rate_3d"],
            "win_rate_4d": confirmed_result["win_rate_4d"],
            "win_rate_5d": confirmed_result["win_rate_5d"],
            "avg_return_1d": confirmed_result["avg_return_1d"],
            "avg_return_2d": confirmed_result["avg_return_2d"],
            "avg_return_3d": confirmed_result["avg_return_3d"],
            "avg_return_4d": confirmed_result["avg_return_4d"],
            "avg_return_5d": confirmed_result["avg_return_5d"],
            "median_return_5d": confirmed_result["median_return_5d"],
            "avg_max_gain_5d": confirmed_result["avg_max_gain_5d"],
            "avg_max_drawdown_5d": confirmed_result["avg_max_drawdown_5d"],
            "profit_factor_5d": confirmed_result["profit_factor_5d"],
            "sample_quality": _sample_quality(self.evaluated_count),
            "conclusion": _strategy_conclusion(
                evaluated_count=conclusion_result["evaluated_count"],
                hit_rate=conclusion_result["net_win_rate"],
                avg_return_5d=conclusion_result["avg_net_return_pct"],
                avg_max_drawdown_5d=conclusion_result["avg_max_drawdown_5d"],
            ),
        }


def build_report(
    *,
    universe_count: int,
    latest_completed: str,
    evaluation_dates: list[str],
    target_profit_pct: float,
    scan_limit: int,
    months: int,
    materialization_mode: str,
    stats: list[StrategyBacktestStats],
    requested_start: str = "",
    requested_end: str = "",
    selected_states: set[str] | None = None,
    execution_model_label: str = "candidate_exit_plan",
    market_guard_label: str = "none",
    prefilter_override_label: str = "none",
) -> dict[str, Any]:
    selected = selected_states or EVALUATED_STATES
    strategy_rows = [item.as_dict(target_profit_pct=target_profit_pct, selected_states=selected) for item in stats]
    family_rows = _build_family_rows(stats=stats, target_profit_pct=target_profit_pct, selected_states=selected)
    all_outcomes = [outcome for item in stats for outcome in item.outcomes]
    snapshot_dates = sorted({trade_date for item in stats for trade_date in item.snapshot_dates})
    materialized_snapshot_count = sum(item.snapshot_count for item in stats)
    expected_snapshot_count = len(evaluation_dates) * len(stats)
    summary = _summary_stats(
        outcomes=all_outcomes,
        target_profit_pct=target_profit_pct,
        selected_states=selected,
        scanned_count=sum(item.scanned_count for item in stats),
        matched_count=sum(item.matched_count for item in stats),
        confirmed_count=sum(item.confirmed_count for item in stats),
        observe_confirmed_count=sum(item.observe_confirmed_count for item in stats),
        near_entry_count=sum(item.near_entry_count for item in stats),
        pending_count=sum(item.pending_count for item in stats),
    )
    summary["backtest_metrics"] = backtest_performance_metrics(all_outcomes, states=CONFIRMED_STATES)
    summary["production_backtest_metrics"] = summary["backtest_metrics"]
    summary["all_evaluated_backtest_metrics"] = backtest_performance_metrics(all_outcomes, states=selected)
    summary.update(
        {
            "universe_count": universe_count,
            "evaluation_start": evaluation_dates[0] if evaluation_dates else "",
            "evaluation_end": evaluation_dates[-1] if evaluation_dates else "",
            "evaluation_trade_days": len(evaluation_dates),
            "snapshot_start": snapshot_dates[0] if snapshot_dates else "",
            "snapshot_end": snapshot_dates[-1] if snapshot_dates else "",
            "snapshot_trade_days": len(snapshot_dates),
            "latest_completed_trade_date": latest_completed,
            "scan_limit_per_day": scan_limit,
            "backtest_window_months": months,
            "requested_start": requested_start,
            "requested_end": requested_end,
            "selected_signal_states": sorted(selected),
            "execution_model": execution_model_label,
            "market_guard": market_guard_label,
            "prefilter_overrides": prefilter_override_label,
            "signal_state_counts": _merge_count_dicts(item.signal_state_counts for item in stats),
            "skipped_by_state_count": sum(item.skipped_by_state_count for item in stats),
            "skipped_by_state_counts": _merge_count_dicts(item.skipped_by_state_counts for item in stats),
            "pending_reason_counts": _merge_count_dicts(item.pending_reason_counts for item in stats),
            "market_guard_count": sum(item.market_guard_count for item in stats),
            "market_guard_counts": _merge_count_dicts(item.market_guard_counts for item in stats),
            "front_row_filter_count": sum(item.front_row_filter_count for item in stats),
            "front_row_filter_counts": _merge_count_dicts(item.front_row_filter_counts for item in stats),
            "not_filled_reason_counts": _reason_counts(
                all_outcomes,
                status="not_filled",
                field="execution_exit_reason",
            ),
            "filled_exit_reason_counts": _reason_counts(
                all_outcomes,
                status="filled",
                field="execution_exit_reason",
            ),
            "data_coverage": data_coverage_summary(
                requested_months=months,
                evaluation_dates=evaluation_dates,
                requested_start=requested_start,
                requested_end=requested_end,
            ),
            "materialization_mode": materialization_mode,
            "completed_snapshot_count": materialized_snapshot_count,
            "completed_snapshot_coverage_pct": pct(materialized_snapshot_count, expected_snapshot_count),
            "materialized_snapshot_count": materialized_snapshot_count,
            "failed_snapshot_count": sum(item.failed_snapshot_count for item in stats),
            "expected_snapshot_count": expected_snapshot_count,
            "materialized_snapshot_coverage_pct": pct(materialized_snapshot_count, expected_snapshot_count),
        }
    )
    return {
        "title": f"低吸策略近 {months} 个月 A 股全市场回测",
        "methodology": [
            "股票池使用 A 股全市场清单计数，策略实际候选由全市场近期涨停/强势结构筛出。",
            "确定买入统计 buy_now / soft_buy_now；观察确认单独统计 observe_confirmed；接近买点单独统计 near_entry，均输出 1/2/3/4/5 日结果。",
            "生产收益、生产排行和真实组合回测只使用 buy_now / soft_buy_now；near_entry 只作为观察提前量，不进入生产收益排行。",
            "真实执行指标按信号后 2 日触达买点、止损/止盈/移动防守退出，并扣除 16bps 成本计算。",
            "每日信号等权复利收益/年化按每日信号等权投入 1 单位资金估算；逐信号无资金约束复利仅保留为诊断字段，不作为真实收益。",
            "真实组合回测新增最大持仓 5/10 两档：持仓期间占用资金，同票持有中禁止重复买入，满仓信号跳过。",
            f"冲高命中按买入后 {PERFORMANCE_FORWARD_DAYS} 个交易日内最高价达到 {target_profit_pct:.1f}% 计算，仅作为辅助观察。",
            "1/2/3/4/5 日收益按触发日参考入场价到后续收盘价计算，用于持股周期观察，并按平均收益给出最佳持股天数。",
            "接近买点样本按买点区参考价估算结果，用于观察信号质量，不等同已经触发买入。",
            f"快照模式：{_materialization_mode_text(materialization_mode)}。",
            f"执行模型：{execution_model_label}。",
            f"市场保护研究模型：{market_guard_label}。",
            f"预筛参数研究覆盖：{prefilter_override_label}。",
        ],
        "summary": summary,
        "families": family_rows,
        "strategies": strategy_rows,
        "top_examples": _top_examples(all_outcomes),
    }


def data_coverage_summary(
    *,
    requested_months: int,
    evaluation_dates: list[str],
    requested_start: str = "",
    requested_end: str = "",
) -> dict[str, Any]:
    if not evaluation_dates:
        return {
            "requested_months": requested_months,
            "requested_start": requested_start,
            "requested_end": requested_end,
            "actual_start": "",
            "actual_end": "",
            "actual_calendar_days": 0,
            "actual_months_estimate": 0.0,
            "coverage_pct": 0.0,
            "status": "empty",
            "warning": "没有可评估交易日，不能作为策略验收证据。",
        }
    start = date.fromisoformat(evaluation_dates[0])
    end = date.fromisoformat(evaluation_dates[-1])
    actual_days = max((end - start).days + 1, 1)
    requested_days = max(int(requested_months or 0) * 31, 1)
    coverage = round(min(actual_days / requested_days * 100.0, 100.0), 2)
    status = "complete" if coverage >= 90.0 else "partial"
    warning = "" if status == "complete" else "本地可评估数据不足请求窗口，报告只能作为部分区间基线，不能替代完整 24 个月验收。"
    return {
        "requested_months": requested_months,
        "requested_start": requested_start,
        "requested_end": requested_end,
        "actual_start": evaluation_dates[0],
        "actual_end": evaluation_dates[-1],
        "actual_calendar_days": actual_days,
        "actual_months_estimate": round(actual_days / 31.0, 2),
        "coverage_pct": coverage,
        "status": status,
        "warning": warning,
    }


def history_window_days(months: int, forward_days: int) -> int:
    return max(260, months * 31 + forward_days + 80)


def _build_family_rows(
    *,
    stats: list[StrategyBacktestStats],
    target_profit_pct: float,
    selected_states: set[str],
) -> list[dict[str, Any]]:
    grouped: dict[str, list[StrategyBacktestStats]] = {}
    for item in stats:
        grouped.setdefault(item.strategy_family, []).append(item)
    rows: list[dict[str, Any]] = []
    for family_key, family_stats in grouped.items():
        outcomes = [outcome for item in family_stats for outcome in item.outcomes]
        confirmed_result = signal_group_stats(
            outcomes=outcomes,
            states=CONFIRMED_STATES,
            target_profit_pct=target_profit_pct,
        )
        near_entry_result = signal_group_stats(
            outcomes=outcomes,
            states={NEAR_ENTRY_STATE},
            target_profit_pct=target_profit_pct,
        )
        buy_now_result = signal_group_stats(
            outcomes=outcomes,
            states={"buy_now"},
            target_profit_pct=target_profit_pct,
        )
        soft_buy_now_result = signal_group_stats(
            outcomes=outcomes,
            states={"soft_buy_now"},
            target_profit_pct=target_profit_pct,
        )
        observe_confirmed_result = signal_group_stats(
            outcomes=outcomes,
            states={OBSERVE_CONFIRMED_STATE},
            target_profit_pct=target_profit_pct,
        )
        total_result = signal_group_stats(
            outcomes=outcomes,
            states=selected_states,
            target_profit_pct=target_profit_pct,
        )
        conclusion_result = conclusion_source(confirmed_result, observe_confirmed_result, near_entry_result)
        family_text = family_stats[0].strategy_family_text if family_stats else resolve_strategy_family_label(family_key)
        rows.append(
            {
                "strategy_family": family_key,
                "strategy_family_text": family_text,
                "strategy_count": len(family_stats),
                "strategy_titles": [item.strategy_title for item in family_stats],
                "snapshot_count": sum(item.snapshot_count for item in family_stats),
                "failed_snapshot_count": sum(item.failed_snapshot_count for item in family_stats),
                "scanned_count": sum(item.scanned_count for item in family_stats),
                "matched_count": sum(item.matched_count for item in family_stats),
                "confirmed_count": sum(item.confirmed_count for item in family_stats),
                "observe_confirmed_count": sum(item.observe_confirmed_count for item in family_stats),
                "near_entry_count": sum(item.near_entry_count for item in family_stats),
                "evaluated_count": sum(item.evaluated_count for item in family_stats),
                "pending_count": sum(item.pending_count for item in family_stats),
                "confirmed_result": confirmed_result,
                "buy_now_result": buy_now_result,
                "soft_buy_now_result": soft_buy_now_result,
                "observe_confirmed_result": observe_confirmed_result,
                "near_entry_result": near_entry_result,
                "total_evaluated_result": total_result,
                "conclusion": _strategy_conclusion(
                    conclusion_result["evaluated_count"],
                    conclusion_result["net_win_rate"],
                    conclusion_result["avg_net_return_pct"],
                    conclusion_result["avg_max_drawdown_5d"],
                ),
            }
        )
    rows.sort(
        key=lambda item: (
            item["confirmed_result"]["filled_count"],
            item["confirmed_result"]["net_win_rate"],
            item["confirmed_result"]["avg_net_return_pct"],
        ),
        reverse=True,
    )
    return rows


def _summary_stats(
    *,
    outcomes: list[TradeOutcome],
    target_profit_pct: float,
    selected_states: set[str],
    scanned_count: int,
    matched_count: int,
    confirmed_count: int,
    observe_confirmed_count: int,
    near_entry_count: int,
    pending_count: int,
) -> dict[str, Any]:
    evaluated = len(outcomes)
    confirmed_result = signal_group_stats(
        outcomes=outcomes,
        states=CONFIRMED_STATES,
        target_profit_pct=target_profit_pct,
    )
    near_entry_result = signal_group_stats(
        outcomes=outcomes,
        states={NEAR_ENTRY_STATE},
        target_profit_pct=target_profit_pct,
    )
    buy_now_result = signal_group_stats(
        outcomes=outcomes,
        states={"buy_now"},
        target_profit_pct=target_profit_pct,
    )
    soft_buy_now_result = signal_group_stats(
        outcomes=outcomes,
        states={"soft_buy_now"},
        target_profit_pct=target_profit_pct,
    )
    observe_confirmed_result = signal_group_stats(
        outcomes=outcomes,
        states={OBSERVE_CONFIRMED_STATE},
        target_profit_pct=target_profit_pct,
    )
    total_result = signal_group_stats(
        outcomes=outcomes,
        states=selected_states,
        target_profit_pct=target_profit_pct,
    )
    conclusion_result = conclusion_source(confirmed_result, observe_confirmed_result, near_entry_result)
    return {
        "scanned_count": scanned_count,
        "matched_count": matched_count,
        "confirmed_count": confirmed_count,
        "observe_confirmed_count": observe_confirmed_count,
        "near_entry_count": near_entry_count,
        "evaluated_count": evaluated,
        "pending_count": pending_count,
        "confirmed_result": confirmed_result,
        "buy_now_result": buy_now_result,
        "soft_buy_now_result": soft_buy_now_result,
        "observe_confirmed_result": observe_confirmed_result,
        "near_entry_result": near_entry_result,
        "total_evaluated_result": total_result,
        "filled_count": confirmed_result["filled_count"],
        "not_filled_rate": confirmed_result["not_filled_rate"],
        "net_win_rate": confirmed_result["net_win_rate"],
        "avg_net_return_pct": confirmed_result["avg_net_return_pct"],
        "stop_loss_rate": confirmed_result["stop_loss_rate"],
        "hit_count": confirmed_result["hit_count"],
        "hit_rate": confirmed_result["hit_rate"],
        "t1_high_3_hit_rate": confirmed_result["t1_high_3_hit_rate"],
        "t1_high_5_hit_rate": confirmed_result["t1_high_5_hit_rate"],
        "t1_fade_to_entry_rate": confirmed_result["t1_fade_to_entry_rate"],
        "avg_t1_high_return_pct": confirmed_result["avg_t1_high_return_pct"],
        "avg_t1_close_return_pct": confirmed_result["avg_t1_close_return_pct"],
        "avg_t1_spike_fade_pct": confirmed_result["avg_t1_spike_fade_pct"],
        "avg_t2_high_return_pct": confirmed_result["avg_t2_high_return_pct"],
        "avg_t2_close_return_pct": confirmed_result["avg_t2_close_return_pct"],
        "win_rate_1d": confirmed_result["win_rate_1d"],
        "win_rate_2d": confirmed_result["win_rate_2d"],
        "win_rate_3d": confirmed_result["win_rate_3d"],
        "win_rate_4d": confirmed_result["win_rate_4d"],
        "win_rate_5d": confirmed_result["win_rate_5d"],
        "avg_return_1d": confirmed_result["avg_return_1d"],
        "avg_return_2d": confirmed_result["avg_return_2d"],
        "avg_return_3d": confirmed_result["avg_return_3d"],
        "avg_return_4d": confirmed_result["avg_return_4d"],
        "avg_return_5d": confirmed_result["avg_return_5d"],
        "median_return_5d": confirmed_result["median_return_5d"],
        "avg_max_gain_5d": confirmed_result["avg_max_gain_5d"],
        "avg_max_drawdown_5d": confirmed_result["avg_max_drawdown_5d"],
        "profit_factor_5d": confirmed_result["profit_factor_5d"],
        "sample_quality": _sample_quality(evaluated),
        "conclusion": _strategy_conclusion(
            conclusion_result["evaluated_count"],
            conclusion_result["net_win_rate"],
            conclusion_result["avg_net_return_pct"],
            conclusion_result["avg_max_drawdown_5d"],
        ),
    }


def _merge_count_dicts(rows: Any) -> dict[str, int]:
    merged: dict[str, int] = {}
    for row in rows:
        for key, value in dict(row or {}).items():
            merged[str(key)] = merged.get(str(key), 0) + int(value or 0)
    return _sorted_counts(merged)


def _sorted_counts(values: dict[str, int]) -> dict[str, int]:
    return {
        key: int(count)
        for key, count in sorted(values.items(), key=lambda item: (-int(item[1] or 0), str(item[0])))
    }


def _reason_counts(
    outcomes: list[TradeOutcome],
    *,
    status: str,
    field: str,
) -> dict[str, int]:
    counts: dict[str, int] = {}
    for item in outcomes:
        if item.execution_status != status:
            continue
        reason = str(getattr(item, field, "") or "未标注原因")
        counts[reason] = counts.get(reason, 0) + 1
    return _sorted_counts(counts)


def backtest_performance_metrics(outcomes: list[TradeOutcome], states: set[str] | None = None) -> dict[str, Any]:
    scoped = [item for item in outcomes if states is None or item.buy_signal_state in states]
    filled = [item for item in scoped if item.execution_status == "filled"]
    returns = [float(item.net_return_pct or 0.0) for item in filled]
    diagnostic_curve = _equity_curve(returns)
    capital_curve = _capital_limited_equity_curve(filled)
    drawdown = _drawdown_stats(capital_curve)
    holding_days = [_holding_days(item) for item in filled if _holding_days(item) > 0]
    wins = [value for value in returns if value > 0]
    losses = [abs(value) for value in returns if value < 0]
    capital_return = round((capital_curve[-1] - 1.0) * 100, 4) if capital_curve else 0.0
    diagnostic_compound_return = round((diagnostic_curve[-1] - 1.0) * 100, 4) if diagnostic_curve else 0.0
    annualized = _annualized_return(capital_return, filled)
    sharpe = _sharpe_ratio(returns)
    daily_returns = _daily_signal_return_stats(filled)
    portfolio_max_5 = portfolio_backtest_metrics(scoped, states=None, max_positions=5)
    portfolio_max_10 = portfolio_backtest_metrics(scoped, states=None, max_positions=10)
    return {
        "trade_count": len(filled),
        "evaluated_count": len(scoped),
        "total_return_pct": capital_return,
        "daily_signal_equal_weight_compound_return_pct": capital_return,
        "annualized_return_pct": annualized,
        "daily_signal_equal_weight_annualized_return_pct": annualized,
        "max_drawdown_pct": drawdown["max_drawdown_pct"],
        "drawdown_recovery_trades": drawdown["drawdown_recovery_trades"],
        "drawdown_recovery_status": drawdown["drawdown_recovery_status"],
        "sharpe_ratio": sharpe,
        "win_rate_pct": pct(len(wins), len(filled)),
        "profit_loss_ratio": round((sum(wins) / len(wins)) / (sum(losses) / len(losses)), 4) if wins and losses else 0.0,
        "profit_factor": profit_factor(wins, losses),
        "avg_holding_days": round(sum(holding_days) / len(holding_days), 2) if holding_days else 0.0,
        "median_holding_days": _median_float(holding_days),
        "avg_net_return_pct": round(sum(returns) / len(returns), 4) if returns else 0.0,
        "median_net_return_pct": _median_float(returns),
        "avg_daily_signal_return_pct": daily_returns["avg_daily_signal_return_pct"],
        "median_daily_signal_return_pct": daily_returns["median_daily_signal_return_pct"],
        "signal_days": daily_returns["signal_days"],
        "avg_trades_per_signal_day": daily_returns["avg_trades_per_signal_day"],
        "max_consecutive_loss_count": _max_consecutive_losses(returns),
        "max_single_loss_pct": round(min(returns), 4) if returns else 0.0,
        "max_single_gain_pct": round(max(returns), 4) if returns else 0.0,
        "capital_model": "one_unit_per_signal_day_equal_weight",
        "capital_model_label": "每日信号等权复利收益",
        "capital_model_note": "每日信号等权复利收益/年化按每日信号等权投入 1 单位资金估算，避免逐信号无资金约束复利夸大。",
        "portfolio_backtests": {
            "max_5": portfolio_max_5,
            "max_10": portfolio_max_10,
        },
        "diagnostic_compound_return_pct": diagnostic_compound_return,
        "diagnostic_compound_return_note": "诊断字段：逐成交信号连续复利，不代表真实资金曲线。",
    }


def portfolio_backtest_metrics(
    outcomes: list[TradeOutcome],
    *,
    states: set[str] | None = None,
    max_positions: int = 5,
    sort_by_production_score: bool = False,
    max_daily_per_strategy: int | None = 2,
    max_per_sector: int | None = 2,
    weak_market_position_cap_pct: float | None = 40.0,
    block_retreat_new_positions: bool = True,
    extra_cost_bps: float = 0.0,
) -> dict[str, Any]:
    scoped = [item for item in outcomes if states is None or item.buy_signal_state in states]
    filled = [item for item in scoped if item.execution_status == "filled"]
    max_slots = max(int(max_positions or 0), 1)
    candidates = sorted(
        filled,
        key=lambda item: (
            _portfolio_entry_date_key(item),
            -_portfolio_priority_score(item) if sort_by_production_score else 0.0,
            str(item.signal_date or ""),
            str(item.symbol or ""),
            str(item.strategy_key or ""),
        ),
    )
    equity = 1.0
    available_cash = 1.0
    curve: list[float] = []
    open_positions: list[dict[str, Any]] = []
    accepted: list[TradeOutcome] = []
    accepted_returns: list[float] = []
    skipped_by_duplicate = 0
    skipped_by_max_positions = 0
    skipped_by_missing_dates = 0
    skipped_by_strategy_daily_limit = 0
    skipped_by_sector_limit = 0
    skipped_by_retreat_market = 0
    skipped_by_weak_market_position_cap = 0
    skip_reason_counts: dict[str, int] = {}
    max_concurrent_positions = 0
    accepted_by_entry_strategy: dict[tuple[date, str], int] = defaultdict(int)

    for item in candidates:
        entry = _portfolio_entry_date(item)
        exit_date = _portfolio_exit_date(item)
        if entry is None or exit_date is None:
            skipped_by_missing_dates += 1
            _record_skip(skip_reason_counts, "missing_entry_or_exit_date")
            continue
        equity, available_cash = _close_portfolio_positions_before(
            open_positions=open_positions,
            before_date=entry,
            equity=equity,
            available_cash=available_cash,
            curve=curve,
        )
        if any(position["symbol"] == item.symbol for position in open_positions):
            skipped_by_duplicate += 1
            _record_skip(skip_reason_counts, "duplicate_symbol_open")
            continue
        market_state = str(item.market_state or item.market_state_category or "")
        if block_retreat_new_positions and market_state in {"high_flyer_retreat", "risk_release"}:
            skipped_by_retreat_market += 1
            _record_skip(skip_reason_counts, "retreat_market_no_new_position")
            continue
        if max_daily_per_strategy is not None and max_daily_per_strategy > 0:
            strategy_key = str(item.strategy_key or "unknown")
            strategy_date_key = (entry, strategy_key)
            if accepted_by_entry_strategy[strategy_date_key] >= max_daily_per_strategy:
                skipped_by_strategy_daily_limit += 1
                _record_skip(skip_reason_counts, "strategy_daily_limit")
                continue
        sector = _portfolio_sector_key(item)
        if max_per_sector is not None and max_per_sector > 0 and sector:
            open_sector_count = sum(1 for position in open_positions if position.get("sector") == sector)
            if open_sector_count >= max_per_sector:
                skipped_by_sector_limit += 1
                _record_skip(skip_reason_counts, "sector_position_limit")
                continue
        if len(open_positions) >= max_slots:
            skipped_by_max_positions += 1
            _record_skip(skip_reason_counts, "max_positions")
            continue
        if weak_market_position_cap_pct is not None and market_state in {"low_volume_wait", "fast_rotation"}:
            weak_cap_slots = max(1, int(max_slots * max(float(weak_market_position_cap_pct), 0.0) / 100.0))
            if len(open_positions) >= weak_cap_slots:
                skipped_by_weak_market_position_cap += 1
                _record_skip(skip_reason_counts, "weak_market_position_cap")
                continue
        slot_capital = equity / max_slots
        if available_cash + 0.0000001 < slot_capital:
            skipped_by_max_positions += 1
            _record_skip(skip_reason_counts, "max_positions_cash_occupied")
            continue
        allocated_capital = slot_capital
        available_cash -= allocated_capital
        open_positions.append(
            {
                "symbol": item.symbol,
                "exit_date": exit_date,
                "return_pct": _portfolio_return_pct(item, extra_cost_bps=extra_cost_bps),
                "allocated_capital": allocated_capital,
                "outcome": item,
                "sector": sector,
            }
        )
        accepted.append(item)
        accepted_returns.append(_portfolio_return_pct(item, extra_cost_bps=extra_cost_bps))
        if max_daily_per_strategy is not None and max_daily_per_strategy > 0:
            accepted_by_entry_strategy[(entry, str(item.strategy_key or "unknown"))] += 1
        max_concurrent_positions = max(max_concurrent_positions, len(open_positions))

    equity, available_cash = _close_all_portfolio_positions(
        open_positions=open_positions,
        equity=equity,
        available_cash=available_cash,
        curve=curve,
    )
    total_return = round((equity - 1.0) * 100.0, 4)
    drawdown = _drawdown_stats(curve)
    wins = [value for value in accepted_returns if value > 0]
    losses = [abs(value) for value in accepted_returns if value < 0]
    holding_days = [_holding_days(item) for item in accepted if _holding_days(item) > 0]
    first_entry = min((_portfolio_entry_date(item) for item in accepted), default=None)
    last_exit = max((_portfolio_exit_date(item) for item in accepted), default=None)
    calendar_days = max((last_exit - first_entry).days + 1, 1) if first_entry and last_exit else 0
    occupied_days = sum(max(_holding_days(item) + 1, 1) for item in accepted)
    utilization = round(occupied_days / max(calendar_days * max_slots, 1) * 100.0, 4) if calendar_days else 0.0
    return {
        "capital_model": f"real_portfolio_max_{max_slots}_equal_slot_no_overlap",
        "capital_model_label": f"真实组合回测 max{max_slots}",
        "max_positions": max_slots,
        "capital_occupied_during_holding": True,
        "available_cash_released_on_exit": True,
        "same_symbol_reentry_blocked": True,
        "strategy_daily_limit": max_daily_per_strategy or 0,
        "sector_daily_limit": max_per_sector or 0,
        "weak_market_position_cap_pct": weak_market_position_cap_pct or 0.0,
        "retreat_market_new_position_blocked": bool(block_retreat_new_positions),
        "production_score_sort_enabled": bool(sort_by_production_score),
        "base_round_trip_cost_bps": ROUND_TRIP_COST_BPS,
        "extra_cost_bps": round(float(extra_cost_bps or 0.0), 4),
        "total_cost_bps_assumption": round(ROUND_TRIP_COST_BPS + float(extra_cost_bps or 0.0), 4),
        "candidate_count": len(filled),
        "trade_count": len(accepted),
        "skipped_count": (
            skipped_by_duplicate
            + skipped_by_max_positions
            + skipped_by_missing_dates
            + skipped_by_strategy_daily_limit
            + skipped_by_sector_limit
            + skipped_by_retreat_market
            + skipped_by_weak_market_position_cap
        ),
        "skipped_by_duplicate_symbol": skipped_by_duplicate,
        "skipped_by_max_positions": skipped_by_max_positions,
        "skipped_by_missing_dates": skipped_by_missing_dates,
        "skipped_by_strategy_daily_limit": skipped_by_strategy_daily_limit,
        "skipped_by_sector_limit": skipped_by_sector_limit,
        "skipped_by_retreat_market": skipped_by_retreat_market,
        "skipped_by_weak_market_position_cap": skipped_by_weak_market_position_cap,
        "skip_reason_counts": _sorted_counts(skip_reason_counts),
        "max_concurrent_positions": max_concurrent_positions,
        "slot_occupancy_days": occupied_days,
        "avg_capital_utilization_pct": utilization,
        "total_return_pct": total_return,
        "portfolio_return_pct": total_return,
        "annualized_return_pct": _annualized_return(total_return, accepted),
        "max_drawdown_pct": drawdown["max_drawdown_pct"],
        "drawdown_recovery_trades": drawdown["drawdown_recovery_trades"],
        "drawdown_recovery_status": drawdown["drawdown_recovery_status"],
        "win_rate_pct": pct(len(wins), len(accepted)),
        "profit_factor": profit_factor(wins, losses),
        "avg_trade_return_pct": round(sum(accepted_returns) / len(accepted_returns), 4) if accepted_returns else 0.0,
        "avg_holding_days": round(sum(holding_days) / len(holding_days), 2) if holding_days else 0.0,
        "concentration": _portfolio_concentration(accepted, accepted_returns),
    }


def _portfolio_return_pct(item: TradeOutcome, *, extra_cost_bps: float = 0.0) -> float:
    return round(float(item.net_return_pct or 0.0) - float(extra_cost_bps or 0.0) / 100.0, 4)


def _portfolio_concentration(accepted: list[TradeOutcome], returns_pct: list[float]) -> dict[str, Any]:
    positive_returns = [max(0.0, value) for value in returns_pct]
    total_positive = sum(positive_returns)
    symbol_profit: dict[str, float] = defaultdict(float)
    strategy_counts: dict[str, int] = defaultdict(int)
    for item, value in zip(accepted, positive_returns):
        symbol_profit[str(item.symbol or "unknown")] += value
        strategy_counts[str(item.strategy_key or "unknown")] += 1
    top_10_profit = sum(sorted(positive_returns, reverse=True)[:10])
    max_symbol_profit = max(symbol_profit.values(), default=0.0)
    top_strategy_count = max(strategy_counts.values(), default=0)
    return {
        "accepted_trade_count": len(accepted),
        "independent_symbol_count": len({str(item.symbol or "") for item in accepted}),
        "strategy_count": len(strategy_counts),
        "top_strategy_trade_share_pct": pct(top_strategy_count, len(accepted)),
        "top_10_positive_trade_contribution_pct": pct(top_10_profit, total_positive),
        "max_symbol_positive_contribution_pct": pct(max_symbol_profit, total_positive),
        "bootstrap_avg_trade_return_ci95_pct": _bootstrap_mean_ci(returns_pct),
    }


def _bootstrap_mean_ci(values: list[float], *, iterations: int = 400) -> dict[str, float]:
    if not values:
        return {"low": 0.0, "mid": 0.0, "high": 0.0}
    if len(values) == 1:
        value = round(float(values[0]), 4)
        return {"low": value, "mid": value, "high": value}
    import random

    rng = random.Random(20260530)
    means: list[float] = []
    count = len(values)
    for _ in range(max(iterations, 1)):
        sample = [values[rng.randrange(count)] for _ in range(count)]
        means.append(sum(sample) / count)
    means.sort()
    low_index = int(0.025 * (len(means) - 1))
    high_index = int(0.975 * (len(means) - 1))
    return {
        "low": round(means[low_index], 4),
        "mid": round(sum(values) / len(values), 4),
        "high": round(means[high_index], 4),
    }


def _portfolio_priority_score(item: TradeOutcome) -> float:
    if item.production_score is not None:
        return float(item.production_score)
    signal_bonus = {"soft_buy_now": 90.0, "buy_now": 80.0, "observe_confirmed": 60.0, "near_entry": 50.0}.get(
        item.buy_signal_state,
        0.0,
    )
    return signal_bonus + float(item.net_return_pct or 0.0) / 1000.0


def _portfolio_sector_key(item: TradeOutcome) -> str:
    sector = str(getattr(item, "sector_name", "") or "").strip()
    if not sector or sector.lower() in {"unknown", "none", "null"}:
        return ""
    return sector


def _record_skip(counts: dict[str, int], reason: str) -> None:
    counts[reason] = counts.get(reason, 0) + 1


def _portfolio_entry_date_key(item: TradeOutcome) -> str:
    entry = _portfolio_entry_date(item)
    return entry.isoformat() if entry is not None else "9999-12-31"


def _portfolio_entry_date(item: TradeOutcome) -> date | None:
    return _parse_trade_date(item.entry_trade_date or item.signal_date)


def _portfolio_exit_date(item: TradeOutcome) -> date | None:
    return _parse_trade_date(item.exit_trade_date or item.entry_trade_date or item.signal_date)


def _parse_trade_date(value: str) -> date | None:
    if not value:
        return None
    try:
        return date.fromisoformat(str(value))
    except ValueError:
        return None


def _close_portfolio_positions_before(
    *,
    open_positions: list[dict[str, Any]],
    before_date: date,
    equity: float,
    available_cash: float,
    curve: list[float],
) -> tuple[float, float]:
    closable = [item for item in open_positions if item["exit_date"] < before_date]
    for position in sorted(closable, key=lambda item: (item["exit_date"], item["symbol"])):
        exit_value = float(position["allocated_capital"]) * max(0.0, 1.0 + float(position["return_pct"]) / 100.0)
        equity += exit_value - float(position["allocated_capital"])
        available_cash += exit_value
        curve.append(equity)
        open_positions.remove(position)
    return equity, available_cash


def _close_all_portfolio_positions(
    *,
    open_positions: list[dict[str, Any]],
    equity: float,
    available_cash: float,
    curve: list[float],
) -> tuple[float, float]:
    for position in sorted(list(open_positions), key=lambda item: (item["exit_date"], item["symbol"])):
        exit_value = float(position["allocated_capital"]) * max(0.0, 1.0 + float(position["return_pct"]) / 100.0)
        equity += exit_value - float(position["allocated_capital"])
        available_cash += exit_value
        curve.append(equity)
        open_positions.remove(position)
    return equity, available_cash


def _equity_curve(returns_pct: list[float]) -> list[float]:
    equity = 1.0
    curve: list[float] = []
    for value in returns_pct:
        equity *= max(0.0, 1.0 + value / 100.0)
        curve.append(equity)
    return curve


def _capital_limited_equity_curve(filled: list[TradeOutcome]) -> list[float]:
    by_date: dict[str, list[float]] = defaultdict(list)
    for item in filled:
        trade_date = item.signal_date or item.entry_trade_date or item.exit_trade_date
        if not trade_date:
            continue
        by_date[str(trade_date)].append(float(item.net_return_pct or 0.0))
    equity = 1.0
    curve: list[float] = []
    for trade_date in sorted(by_date):
        returns = by_date[trade_date]
        if not returns:
            continue
        daily_return = sum(returns) / len(returns)
        equity *= max(0.0, 1.0 + daily_return / 100.0)
        curve.append(equity)
    return curve


def _daily_signal_return_stats(filled: list[TradeOutcome]) -> dict[str, Any]:
    by_date: dict[str, list[float]] = defaultdict(list)
    for item in filled:
        trade_date = item.signal_date or item.entry_trade_date or item.exit_trade_date
        if not trade_date:
            continue
        by_date[str(trade_date)].append(float(item.net_return_pct or 0.0))
    daily_returns = [sum(values) / len(values) for _, values in sorted(by_date.items()) if values]
    trade_counts = [len(values) for values in by_date.values() if values]
    return {
        "signal_days": len(daily_returns),
        "avg_daily_signal_return_pct": round(sum(daily_returns) / len(daily_returns), 4) if daily_returns else 0.0,
        "median_daily_signal_return_pct": _median_float(daily_returns),
        "avg_trades_per_signal_day": round(sum(trade_counts) / len(trade_counts), 2) if trade_counts else 0.0,
    }


def _max_consecutive_losses(returns_pct: list[float]) -> int:
    longest = 0
    current = 0
    for value in returns_pct:
        if value < 0:
            current += 1
            longest = max(longest, current)
        else:
            current = 0
    return longest


def _drawdown_stats(equity_curve: list[float]) -> dict[str, Any]:
    if not equity_curve:
        return {"max_drawdown_pct": 0.0, "drawdown_recovery_trades": 0, "drawdown_recovery_status": "无成交"}
    peak = 1.0
    peak_index = 0
    max_drawdown = 0.0
    trough_index = 0
    recovery_trades = 0
    recovered = True
    for index, equity in enumerate(equity_curve):
        if equity > peak:
            peak = equity
            peak_index = index
        drawdown = equity / max(peak, 0.000001) - 1.0
        if drawdown < max_drawdown:
            max_drawdown = drawdown
            trough_index = index
            recovered = False
            recovery_trades = 0
        elif not recovered and equity >= peak:
            recovered = True
            recovery_trades = index - trough_index
    if max_drawdown == 0.0:
        status = "未发生回撤"
    elif recovered:
        status = f"最大回撤后 {recovery_trades} 笔交易恢复"
    else:
        status = "截至回测结束尚未恢复最大回撤"
        recovery_trades = len(equity_curve) - trough_index - 1
    return {
        "max_drawdown_pct": round(max_drawdown * 100, 4),
        "drawdown_recovery_trades": recovery_trades,
        "drawdown_recovery_status": status,
        "peak_trade_index": peak_index,
        "trough_trade_index": trough_index,
    }


def _annualized_return(total_return_pct: float, filled: list[TradeOutcome]) -> float:
    dates = sorted({item.signal_date for item in filled if item.signal_date})
    if len(dates) < 2:
        return 0.0
    try:
        start = date.fromisoformat(dates[0])
        end = date.fromisoformat(dates[-1])
    except ValueError:
        return 0.0
    days = max((end - start).days, 1)
    total_multiple = max(0.0, 1.0 + total_return_pct / 100.0)
    if total_multiple <= 0:
        return -100.0
    return round((total_multiple ** (365.0 / days) - 1.0) * 100.0, 4)


def _sharpe_ratio(returns_pct: list[float]) -> float:
    if len(returns_pct) < 2:
        return 0.0
    mean_value = sum(returns_pct) / len(returns_pct)
    variance = sum((value - mean_value) ** 2 for value in returns_pct) / (len(returns_pct) - 1)
    stddev = math.sqrt(variance)
    if stddev <= 0:
        return 0.0
    return round((mean_value / stddev) * math.sqrt(252), 4)


def _holding_days(item: TradeOutcome) -> int:
    if not item.entry_trade_date or not item.exit_trade_date:
        return 0
    try:
        return max((date.fromisoformat(item.exit_trade_date) - date.fromisoformat(item.entry_trade_date)).days, 0)
    except ValueError:
        return 0


def _median_float(values: list[int]) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    mid = len(ordered) // 2
    if len(ordered) % 2:
        return float(ordered[mid])
    return round((ordered[mid - 1] + ordered[mid]) / 2.0, 2)


def _top_examples(outcomes: list[TradeOutcome], limit: int = 20) -> list[dict[str, Any]]:
    ordered = sorted(outcomes, key=lambda item: item.max_gain_5d, reverse=True)
    return [item.__dict__ for item in ordered[:limit]]


def _strategy_conclusion(
    evaluated_count: int,
    hit_rate: float,
    avg_return_5d: float,
    avg_max_drawdown_5d: float,
) -> str:
    if evaluated_count < 30:
        return "样本不足，只能作为观察结论。"
    if avg_return_5d > 0.8 and hit_rate >= 50 and avg_max_drawdown_5d > -5.5:
        return "阶段可行，适合继续保留并用仓位控制执行。"
    if avg_return_5d > 0 and hit_rate >= 42:
        return "有一定可行性，但需要继续用市场状态和行业强弱过滤。"
    return "阶段表现不足，生产交易应降权或只保留观察。"


def _sample_quality(evaluated_count: int) -> str:
    if evaluated_count >= 100:
        return "高"
    if evaluated_count >= 30:
        return "中"
    return "低"


def _materialization_mode_text(mode: str) -> str:
    labels = {
        "isolated": "隔离计算，不写入线上物化结果表",
        "production": "写入线上物化结果表，仅用于明确需要回灌缓存的任务",
        "read-only": "只读取已有物化结果，不补算缺失日期",
    }
    return labels.get(mode, mode)


try:
    from .low_buy_market_backtest_markdown import render_markdown_report
except ImportError:
    from low_buy_market_backtest_markdown import render_markdown_report
